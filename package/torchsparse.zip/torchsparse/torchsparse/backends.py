def init():
    global benchmark
    benchmark = False
